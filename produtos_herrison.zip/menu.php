<header class="p-2 text-bg-dark">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                <li><a href="inicio.php" class="nav-link text-white link-menu"> Produtos </a></li>
                <li><a href="estabelecimentos.php" class="nav-link text-white link-menu"> Estabelecimentos </a></li>
                <li><a href="produtoEstabelecimento.php" class="nav-link text-white link-menu"> Produto X Estabelecimento </a></li>
                <li><a href="pesquisa.php" class="nav-link text-white link-menu"> Pesquisa de preços </a></li>
            </ul>

            <div class="text-end">
                <a type="button" class="btn btn-warning" href="config/logout.php"> <i class="fa-solid fa-arrow-right-from-bracket"></i> Desconectar </a>
            </div>
        </div>
    </div>
</header>