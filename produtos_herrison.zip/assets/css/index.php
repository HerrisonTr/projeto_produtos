<?php

header("Location: ../");